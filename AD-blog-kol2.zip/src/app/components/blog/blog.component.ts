import {Component, EventEmitter, OnInit, Output} from '@angular/core';
import {DataService} from '../../services/ad-data.service';

@Component({
  selector: 'blog',
  templateUrl: './blog.component.html',
  styleUrls: ['./blog.component.css']
})
export class BlogComponent implements OnInit {
  public items$: any;
  constructor(private service: DataService) {
  }

ngOnInit(): void {
    this.getAll();
  }

  getAll(){
       this.service.getAll().subscribe(response => {
       console.log(response);
       this.items$ = response;
     });
  }
}
