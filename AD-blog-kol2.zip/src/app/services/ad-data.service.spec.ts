import { TestBed } from '@angular/core/testing';

import { ADDataService } from './ad-data.service';

describe('ADDataService', () => {
  let service: ADDataService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ADDataService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
